# Command-Line To-Do List Manager

## Requirements
- GCC C compiler
- Visual Studio Code (or another code editor)

## Run in VS Code terminal
Open this folder in VS Code, then run:

```bash
gcc todo.c -o todo
```

On Windows:
```powershell
.\todo.exe
```

On macOS/Linux:
```bash
./todo
```

## Menu
1. Add Task
2. Display Tasks
3. Remove Task
4. Mark Task Complete
5. Save Tasks
6. Exit

Tasks are loaded from `tasks.txt` at startup and saved when you choose Save or Exit.
