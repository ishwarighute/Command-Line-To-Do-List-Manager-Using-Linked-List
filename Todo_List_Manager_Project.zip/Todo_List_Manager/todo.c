#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Task {
    int id;
    char description[200];
    int completed;
    struct Task *next;
} Task;

Task *head = NULL;
int nextId = 1;

void addTask(void) {
    Task *newTask = (Task *)malloc(sizeof(Task));
    if (newTask == NULL) {
        printf("Memory allocation failed!\n");
        return;
    }

    newTask->id = nextId++;
    printf("Enter task description: ");
    getchar(); /* consume newline left by scanf */
    if (fgets(newTask->description, sizeof(newTask->description), stdin) == NULL) {
        free(newTask);
        printf("Could not read task.\n");
        return;
    }
    newTask->description[strcspn(newTask->description, "\n")] = '\0';
    newTask->completed = 0;
    newTask->next = NULL;

    if (head == NULL) {
        head = newTask;
    } else {
        Task *temp = head;
        while (temp->next != NULL) temp = temp->next;
        temp->next = newTask;
    }
    printf("Task added successfully!\n");
}

void displayTasks(void) {
    Task *temp = head;
    if (temp == NULL) {
        printf("\nNo tasks available!\n");
        return;
    }

    printf("\n------ TO-DO LIST ------\n");
    while (temp != NULL) {
        printf("ID: %d\n", temp->id);
        printf("Task: %s\n", temp->description);
        printf("Status: %s\n", temp->completed ? "Completed" : "Pending");
        printf("------------------------\n");
        temp = temp->next;
    }
}

void removeTask(void) {
    int id;
    printf("Enter task ID to remove: ");
    if (scanf("%d", &id) != 1) {
        printf("Invalid ID.\n");
        return;
    }

    Task *temp = head;
    Task *prev = NULL;
    while (temp != NULL && temp->id != id) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) {
        printf("Task not found!\n");
        return;
    }

    if (prev == NULL) head = temp->next;
    else prev->next = temp->next;

    free(temp);
    printf("Task removed successfully!\n");
}

void markComplete(void) {
    int id;
    printf("Enter task ID: ");
    if (scanf("%d", &id) != 1) {
        printf("Invalid ID.\n");
        return;
    }

    Task *temp = head;
    while (temp != NULL) {
        if (temp->id == id) {
            temp->completed = 1;
            printf("Task marked as completed!\n");
            return;
        }
        temp = temp->next;
    }
    printf("Task not found!\n");
}

void saveTasks(void) {
    FILE *fp = fopen("tasks.txt", "w");
    if (fp == NULL) {
        printf("Unable to save tasks!\n");
        return;
    }

    Task *temp = head;
    while (temp != NULL) {
        fprintf(fp, "%d|%d|%s\n", temp->id, temp->completed, temp->description);
        temp = temp->next;
    }
    fclose(fp);
}

void loadTasks(void) {
    FILE *fp = fopen("tasks.txt", "r");
    if (fp == NULL) return;

    char line[250];
    while (fgets(line, sizeof(line), fp) != NULL) {
        Task *newTask = (Task *)malloc(sizeof(Task));
        if (newTask == NULL) break;

        if (sscanf(line, "%d|%d|%199[^\n]",
                   &newTask->id, &newTask->completed,
                   newTask->description) != 3) {
            free(newTask);
            continue;
        }

        newTask->next = NULL;
        if (head == NULL) head = newTask;
        else {
            Task *temp = head;
            while (temp->next != NULL) temp = temp->next;
            temp->next = newTask;
        }
        if (newTask->id >= nextId) nextId = newTask->id + 1;
    }
    fclose(fp);
}

void freeTasks(void) {
    while (head != NULL) {
        Task *temp = head;
        head = head->next;
        free(temp);
    }
}

int main(void) {
    int choice;
    loadTasks();

    printf("Welcome to To-Do List Manager!\n");
    while (1) {
        printf("\n===== TO-DO LIST MANAGER =====\n");
        printf("1. Add Task\n");
        printf("2. Display Tasks\n");
        printf("3. Remove Task\n");
        printf("4. Mark Task Complete\n");
        printf("5. Save Tasks\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            printf("Please enter a number from 1 to 6.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) { }
            continue;
        }

        switch (choice) {
            case 1: addTask(); break;
            case 2: displayTasks(); break;
            case 3: removeTask(); break;
            case 4: markComplete(); break;
            case 5: saveTasks(); printf("Tasks saved successfully!\n"); break;
            case 6:
                saveTasks();
                freeTasks();
                printf("Tasks saved. Thank you!\n");
                return 0;
            default: printf("Invalid choice! Try again.\n");
        }
    }
}
